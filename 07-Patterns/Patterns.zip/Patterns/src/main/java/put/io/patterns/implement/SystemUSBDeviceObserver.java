package put.io.patterns.implement;

public class SystemUSBDeviceObserver implements SystemStateObserver{
    private SystemState lastSystemState = null;
    private int no_USB = 0;
    private int counter = 0;
    @Override
    public void update(SystemMonitor monitor) {
        if(counter == 0) {
            lastSystemState = monitor.getLastSystemState();
            counter++;
        }

        no_USB = lastSystemState.getUsbDevices();
        lastSystemState = monitor.getLastSystemState();

        if(no_USB != lastSystemState.getUsbDevices()){
            System.out.println("> Number of USBDevices has changed");
        }
    }
}
